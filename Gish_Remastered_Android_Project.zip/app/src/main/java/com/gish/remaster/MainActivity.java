package com.gish.remaster;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {
    private GishGameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        gameView = new GishGameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameView.resume();
    }

    public static class GishGameView extends View implements Runnable {
        private Thread gameThread;
        private volatile boolean playing = false;
        private Paint paint;
        private Canvas canvas;

        // Game state: 0 = Menu, 1 = Playing, 2 = Victory, 3 = Level Select
        private int gameState = 0;

        // Player physics & position
        private float playerX = 200;
        private float playerY = 300;
        private float playerVx = 0;
        private float playerVy = 0;
        private float playerRadius = 36f;
        private boolean isSticky = false;
        private boolean isSpars = false;
        private boolean isHeavy = false;

        // Level & World
        private int currentLevel = 1;
        private float cameraX = 0;
        private float cameraY = 0;
        private List<Platform> platforms = new ArrayList<>();
        private List<Enemy> enemies = new ArrayList<>();
        private List<Collectible> collectibles = new ArrayList<>();
        private float goalX = 2500;
        private float goalY = 400;

        // Touch controls
        private boolean btnLeft = false;
        private boolean btnRight = false;
        private boolean btnJump = false;
        private boolean btnSticky = false;
        private boolean btnHeavy = false;

        // Screen dimensions
        private int screenWidth = 1920;
        private int screenHeight = 1080;

        public GishGameView(Context context) {
            super(context);
            paint = new Paint();
            paint.setAntiAlias(true);
            initLevel(1);
        }

        public void initLevel(int levelNum) {
            currentLevel = levelNum;
            playerX = 150;
            playerY = 400;
            playerVx = 0;
            playerVy = 0;
            platforms.clear();
            enemies.clear();
            collectibles.clear();

            // Build platforms
            platforms.add(new Platform(-500, 850, 4000, 200, Color.rgb(30, 25, 20))); // Ground
            platforms.add(new Platform(600, 650, 300, 40, Color.rgb(50, 40, 30)));
            platforms.add(new Platform(1100, 500, 350, 40, Color.rgb(50, 40, 30)));
            platforms.add(new Platform(1600, 400, 400, 40, Color.rgb(50, 40, 30)));
            platforms.add(new Platform(2200, 600, 300, 40, Color.rgb(50, 40, 30)));

            // Walls & obstacles
            platforms.add(new Platform(950, 500, 50, 350, Color.rgb(40, 30, 25)));
            platforms.add(new Platform(1500, 300, 50, 550, Color.rgb(40, 30, 25)));

            // Enemies
            enemies.add(new Enemy(700, 600, 500, 900));
            enemies.add(new Enemy(1200, 450, 1100, 1400));
            enemies.add(new Enemy(1700, 350, 1600, 1950));

            // Collectibles (Tar / Amber)
            for (int i = 0; i < 8; i++) {
                collectibles.add(new Collectible(500 + i * 300, 300 + (i % 2) * 150));
            }

            goalX = 2700;
            goalY = 750;
        }

        public void resume() {
            playing = true;
            gameThread = new Thread(this);
            gameThread.start();
        }

        public void pause() {
            playing = false;
            try {
                if (gameThread != null) {
                    gameThread.join();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            long lastTime = System.nanoTime();
            final double nsPerTick = 1000000000.0 / 60.0;
            double delta = 0;

            while (playing) {
                long now = System.nanoTime();
                delta += (now - lastTime) / nsPerTick;
                lastTime = now;

                if (delta >= 1) {
                    update();
                    delta--;
                }

                try {
                    Thread.sleep(2);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (getWidth() > 0 && getHeight() > 0) {
                    screenWidth = getWidth();
                    screenHeight = getHeight();
                    postInvalidate();
                }
            }
        }

        private void update() {
            if (gameState != 1) return; // Only update gameplay when playing

            // Physics constants
            float gravity = 0.6f;
            float friction = 0.85f;
            float moveAccel = 1.2f;

            if (isHeavy) {
                gravity = 1.4f;
                playerRadius = 45f;
            } else {
                playerRadius = 36f;
            }

            // Horizontal movement
            if (btnLeft) {
                playerVx -= moveAccel;
            }
            if (btnRight) {
                playerVx += moveAccel;
            }

            playerVx *= friction;
            playerVy += gravity;

            // Sticky wall / ceiling mechanics
            isSticky = btnSticky;
            if (isSticky) {
                playerVy *= 0.2f;
                playerVx *= 0.5f;
            }

            // Jump
            if (btnJump) {
                // Check if on ground or sticky
                playerVy = -13.5f;
                btnJump = false; // consume jump
            }

            // Update position
            playerX += playerVx;
            playerY += playerVy;

            // Platform collisions
            for (Platform p : platforms) {
                // Simple AABB collision with resolution
                if (playerX + playerRadius > p.x && playerX - playerRadius < p.x + p.w &&
                    playerY + playerRadius > p.y && playerY - playerRadius < p.y + p.h) {
                    
                    // Collision from top
                    if (playerVy > 0 && playerY - playerRadius < p.y) {
                        playerY = p.y - playerRadius;
                        playerVy = 0;
                        if (btnJump) {
                            playerVy = -13.5f;
                        }
                    }
                    // Collision from bottom
                    else if (playerVy < 0 && playerY + playerRadius > p.y + p.h) {
                        playerY = p.y + p.h + playerRadius;
                        playerVy = 0;
                    }
                    // Collision from sides
                    else if (playerVx > 0) {
                        playerX = p.x - playerRadius;
                        playerVx = 0;
                        if (isSticky) {
                            playerVy = 0; // Stick to wall
                        }
                    } else if (playerVx < 0) {
                        playerX = p.x + p.w + playerRadius;
                        playerVx = 0;
                        if (isSticky) {
                            playerVy = 0;
                        }
                    }
                }
            }

            // Update enemies
            for (Enemy e : enemies) {
                e.update();
                // Collision with player
                float dx = playerX - e.x;
                float dy = playerY - e.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist < playerRadius + e.radius) {
                    if (isHeavy || playerVy > 5f) {
                        e.alive = false; // Squash enemy!
                        playerVy = -10f; // Bounce
                    } else {
                        // Take damage / knockback
                        playerVx = (playerX < e.x) ? -12f : 12f;
                        playerVy = -8f;
                    }
                }
            }

            // Collectibles
            for (Collectible c : collectibles) {
                if (!c.collected) {
                    float dx = playerX - c.x;
                    float dy = playerY - c.y;
                    if (Math.sqrt(dx * dx + dy * dy) < playerRadius + 20f) {
                        c.collected = true;
                    }
                }
            }

            // Check goal / exit
            float gdx = playerX - goalX;
            float gdy = playerY - goalY;
            if (Math.sqrt(gdx * gdx + gdy * gdy) < 60f) {
                // Level complete!
                if (currentLevel < 5) {
                    initLevel(currentLevel + 1);
                } else {
                    gameState = 2; // Victory
                }
            }

            // Fall into pit
            if (playerY > 1200) {
                initLevel(currentLevel); // Respawn
            }

            // Camera follow player smoothly
            float targetCamX = playerX - screenWidth / 2f;
            cameraX += (targetCamX - cameraX) * 0.1f;
            if (cameraX < -200) cameraX = -200;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            this.canvas = canvas;

            // Background gradient (Dark atmospheric Gish style)
            canvas.drawColor(Color.rgb(15, 12, 10));

            if (gameState == 0) {
                // MAIN MENU
                drawMainMenu(canvas);
            } else if (gameState == 1) {
                // GAMEPLAY
                canvas.save();
                canvas.translate(-cameraX, 0);

                // Draw platforms
                for (Platform p : platforms) {
                    paint.setColor(p.color);
                    canvas.drawRect(p.x, p.y, p.x + p.w, p.y + p.h, paint);
                    // Add slimy highlight on top
                    paint.setColor(Color.rgb(70, 60, 50));
                    canvas.drawRect(p.x, p.y, p.x + p.w, p.y + 6, paint);
                }

                // Draw goal (Exit portal / Cage)
                paint.setColor(Color.rgb(255, 200, 50));
                canvas.drawCircle(goalX, goalY, 40f, paint);
                paint.setColor(Color.rgb(200, 150, 0));
                canvas.drawCircle(goalX, goalY, 30f, paint);

                // Draw collectibles
                for (Collectible c : collectibles) {
                    if (!c.collected) {
                        paint.setColor(Color.rgb(255, 180, 0));
                        canvas.drawCircle(c.x, c.y + (float)Math.sin(System.currentTimeMillis()*0.01)*5f, 16f, paint);
                    }
                }

                // Draw enemies
                for (Enemy e : enemies) {
                    if (e.alive) {
                        paint.setColor(Color.rgb(180, 40, 40));
                        canvas.drawCircle(e.x, e.y, e.radius, paint);
                        // Eyes
                        paint.setColor(Color.WHITE);
                        canvas.drawCircle(e.x - 10, e.y - 5, 8f, paint);
                        canvas.drawCircle(e.x + 10, e.y - 5, 8f, paint);
                        paint.setColor(Color.BLACK);
                        canvas.drawCircle(e.x - 10, e.y - 5, 3f, paint);
                        canvas.drawCircle(e.x + 10, e.y - 5, 3f, paint);
                    }
                }

                // Draw Player (Gish - realistic tar blob with squash & stretch)
                drawGish(canvas, playerX, playerY, playerRadius, playerVx, playerVy);

                canvas.restore();

                // Draw UI / HUD
                drawHUD(canvas);

                // Draw On-Screen Touch Controls
                drawControls(canvas);

            } else if (gameState == 2) {
                // VICTORY SCREEN
                drawVictoryScreen(canvas);
            }
        }

        private void drawGish(Canvas canvas, float x, float y, float r, float vx, float vy) {
            paint.setColor(Color.rgb(25, 20, 18)); // Outer tar shadow
            canvas.drawCircle(x, y + 5, r + 4, paint);

            // Body (squash & stretch based on velocity)
            float stretchX = r + Math.abs(vx) * 0.8f;
            float stretchY = r - Math.abs(vy) * 0.6f;
            if (stretchX < r * 0.8f) stretchX = r * 0.8f;
            if (stretchY < r * 0.7f) stretchY = r * 0.7f;

            paint.setColor(Color.rgb(10, 8, 7));
            canvas.drawOval(x - stretchX, y - stretchY, x + stretchX, y + stretchY, paint);

            // Gish inner tar sheen
            paint.setColor(Color.rgb(45, 38, 35));
            canvas.drawOval(x - stretchX * 0.7f, y - stretchY * 0.7f, x + stretchX * 0.4f, y, paint);

            // Eyes (glowing white with black pupils)
            float eyeOffsetX = vx * 0.5f;
            paint.setColor(Color.WHITE);
            canvas.drawCircle(x - 12 + eyeOffsetX, y - 8, 10f, paint);
            canvas.drawCircle(x + 12 + eyeOffsetX, y - 8, 10f, paint);

            paint.setColor(Color.BLACK);
            canvas.drawCircle(x - 12 + eyeOffsetX + vx*0.2f, y - 8, 4f, paint);
            canvas.drawCircle(x + 12 + eyeOffsetX + vx*0.2f, y - 8, 4f, paint);

            // Sticky indicator
            if (isSticky) {
                paint.setColor(Color.rgb(255, 100, 0));
                paint.setStrokeWidth(4f);
                canvas.drawCircle(x, y, r + 8, paint);
            }
            if (isHeavy) {
                paint.setColor(Color.rgb(100, 100, 255));
                paint.setStrokeWidth(6f);
                canvas.drawCircle(x, y, r + 10, paint);
            }
        }

        private void drawMainMenu(Canvas canvas) {
            // Title background
            paint.setColor(Color.rgb(20, 15, 10));
            canvas.drawRect(0, 0, screenWidth, screenHeight, paint);

            // Title text
            paint.setColor(Color.rgb(255, 140, 20));
            paint.setTextSize(120f);
            paint.setFakeBoldText(true);
            canvas.drawText("GISH REMASTERED", screenWidth / 2f - 450, screenHeight / 2f - 150, paint);

            paint.setColor(Color.rgb(180, 170, 160));
            paint.setTextSize(45f);
            canvas.drawText("Java ME Classic Reborn for Android", screenWidth / 2f - 320, screenHeight / 2f - 70, paint);

            // Play Button
            paint.setColor(Color.rgb(200, 90, 10));
            canvas.drawRect(screenWidth / 2f - 200, screenHeight / 2f + 20, screenWidth / 2f + 200, screenHeight / 2f + 140, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(60f);
            canvas.drawText("PLAY GAME", screenWidth / 2f - 150, screenHeight / 2f + 100, paint);

            paint.setTextSize(35f);
            paint.setColor(Color.rgb(150, 140, 130));
            canvas.drawText("Tap Play to start adventure across 5 remastered levels", screenWidth / 2f - 380, screenHeight / 2f + 220, paint);
        }

        private void drawVictoryScreen(Canvas canvas) {
            paint.setColor(Color.rgb(20, 15, 10));
            canvas.drawRect(0, 0, screenWidth, screenHeight, paint);

            paint.setColor(Color.rgb(255, 200, 50));
            paint.setTextSize(100f);
            canvas.drawText("VICTORY!", screenWidth / 2f - 250, screenHeight / 2f - 100, paint);

            paint.setColor(Color.WHITE);
            paint.setTextSize(45f);
            canvas.drawText("You successfully completed Gish Remastered!", screenWidth / 2f - 380, screenHeight / 2f - 20, paint);

            // Restart Button
            paint.setColor(Color.rgb(200, 90, 10));
            canvas.drawRect(screenWidth / 2f - 200, screenHeight / 2f + 50, screenWidth / 2f + 200, screenHeight / 2f + 150, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(50f);
            canvas.drawText("MAIN MENU", screenWidth / 2f - 140, screenHeight / 2f + 115, paint);
        }

        private void drawHUD(Canvas canvas) {
            paint.setColor(Color.argb(180, 0, 0, 0));
            canvas.drawRect(30, 30, 350, 130, paint);

            paint.setColor(Color.WHITE);
            paint.setTextSize(40f);
            canvas.drawText("LEVEL: " + currentLevel + " / 5", 50, 80, paint);
            
            int collectedCount = 0;
            for (Collectible c : collectibles) if (c.collected) collectedCount++;
            canvas.drawText("TAR: " + collectedCount + " / " + collectibles.size(), 50, 120, paint);
        }

        private void drawControls(Canvas canvas) {
            // Left / Right D-Pad
            drawButton(canvas, 100, screenHeight - 220, 140, 140, "<", btnLeft);
            drawButton(canvas, 280, screenHeight - 220, 140, 140, ">", btnRight);

            // Actions: Jump, Sticky, Heavy
            drawButton(canvas, screenWidth - 220, screenHeight - 220, 130, 130, "JUMP", btnJump);
            drawButton(canvas, screenWidth - 380, screenHeight - 120, 110, 110, "STICK", btnSticky);
            drawButton(canvas, screenWidth - 120, screenHeight - 360, 110, 110, "HEAVY", btnHeavy);
        }

        private void drawButton(Canvas canvas, float x, float y, float w, float h, String label, boolean pressed) {
            paint.setColor(pressed ? Color.rgb(255, 140, 20) : Color.argb(120, 60, 50, 40));
            canvas.drawRoundRect(x, y, x + w, y + h, 25f, 25f, paint);

            paint.setColor(Color.WHITE);
            paint.setTextSize(36f);
            canvas.drawText(label, x + w / 2f - paint.measureText(label) / 2f, y + h / 2f + 12f, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int pointerIndex = event.getActionIndex();
            int x = (int) event.getX(pointerIndex);
            int y = (int) event.getY(pointerIndex);

            if (gameState == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    if (x > screenWidth / 2f - 200 && x < screenWidth / 2f + 200 &&
                        y > screenHeight / 2f + 20 && y < screenHeight / 2f + 140) {
                        gameState = 1; // Start Game
                        initLevel(1);
                    }
                }
                return true;
            } else if (gameState == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    if (x > screenWidth / 2f - 200 && x < screenWidth / 2f + 200 &&
                        y > screenHeight / 2f + 50 && y < screenHeight / 2f + 150) {
                        gameState = 0; // Main menu
                    }
                }
                return true;
            }

            // Gameplay touch handling (Multi-touch)
            btnLeft = false;
            btnRight = false;
            btnJump = false;
            btnSticky = false;
            btnHeavy = false;

            for (int i = 0; i < event.getPointerCount(); i++) {
                int px = (int) event.getX(i);
                int py = (int) event.getY(i);
                int pAction = event.getActionMasked();

                if (pAction == MotionEvent.ACTION_UP || pAction == MotionEvent.ACTION_POINTER_UP) {
                    if (i == pointerIndex) continue;
                }

                // Check buttons
                if (px >= 100 && px <= 240 && py >= screenHeight - 220 && py <= screenHeight - 80) {
                    btnLeft = true;
                }
                if (px >= 280 && px <= 420 && py >= screenHeight - 220 && py <= screenHeight - 80) {
                    btnRight = true;
                }
                if (px >= screenWidth - 220 && px <= screenWidth - 90 && py >= screenHeight - 220 && py <= screenHeight - 90) {
                    btnJump = true;
                }
                if (px >= screenWidth - 380 && px <= screenWidth - 270 && py >= screenHeight - 120 && py <= screenHeight - 10) {
                    btnSticky = true;
                }
                if (px >= screenWidth - 120 && px <= screenWidth - 10 && py >= screenHeight - 360 && py <= screenHeight - 250) {
                    btnHeavy = true;
                }
            }

            return true;
        }
    }

    public static class Platform {
        public float x, y, w, h;
        public int color;
        public Platform(float x, float y, float w, float h, int color) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.color = color;
        }
    }

    public static class Enemy {
        public float x, y, minX, maxX;
        public float vx = 2f;
        public float radius = 30f;
        public boolean alive = true;

        public Enemy(float x, float y, float minX, float maxX) {
            this.x = x; this.y = y; this.minX = minX; this.maxX = maxX;
        }

        public void update() {
            if (!alive) return;
            x += vx;
            if (x < minX || x > maxX) {
                vx = -vx;
            }
        }
    }

    public static class Collectible {
        public float x, y;
        public boolean collected = false;
        public Collectible(float x, float y) {
            this.x = x; this.y = y;
        }
    }
}
